# Analog Clock

A simple analog clock created with `html`, `css` and `javascript`. Shows time based on browser time.
